using System.ComponentModel.DataAnnotations;

namespace QuizApp.Models
{
  public class Odpowiedz
  {
    public int Id { get; set; }

    [Required(ErrorMessage = "Treść odpowiedzi jest wymagana")]
    [StringLength(300, ErrorMessage = "Treść odpowiedzi może mieć maximum 300 znaków")]
    public string Tresc { get; set; } = string.Empty;

    public bool CzyPoprawna { get; set; }

    [Required]
    public int PytanieId { get; set; }

    // Nawigacja do pytania
    public Pytanie? Pytanie { get; set; }

    // Nawigacja do odpowiedzi użytkowników
    public ICollection<OdpowiedzUzytkownika> OdpowiedziUzytkownikow { get; set; } = new List<OdpowiedzUzytkownika>();
  }
}