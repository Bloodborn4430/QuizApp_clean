using System.ComponentModel.DataAnnotations;

namespace QuizApp.Models
{
  public class Pytanie
  {
    public int Id { get; set; }

    [Required(ErrorMessage = "Treść pytania jest wymagana")]
    [StringLength(500, ErrorMessage = "Treść pytania może mieć maximum 500 znaków")]
    public string Tresc { get; set; } = string.Empty;

    [Required(ErrorMessage = "Liczba punktów jest wymagana")]
    [Range(1, 100, ErrorMessage = "Liczba punktów musi być między 1 a 100")]
    public int LiczbaPunktow { get; set; }

    [Required]
    public int QuizId { get; set; }

    // Nawigacja do quizu
    public Quiz? Quiz { get; set; }

    // Nawigacja do odpowiedzi
    public ICollection<Odpowiedz> Odpowiedzi { get; set; } = new List<Odpowiedz>();

    // Nawigacja do odpowiedzi użytkowników
    public ICollection<OdpowiedzUzytkownika> OdpowiedziUzytkownikow { get; set; } = new List<OdpowiedzUzytkownika>();
  }

  // ViewModel dla tworzenia pytania z odpowiedziami
  public class CreatePytanieViewModel
  {
    [Required(ErrorMessage = "Treść pytania jest wymagana")]
    [StringLength(500, ErrorMessage = "Treść pytania może mieć maximum 500 znaków")]
    public string Tresc { get; set; } = string.Empty;

    [Required(ErrorMessage = "Liczba punktów jest wymagana")]
    [Range(1, 100, ErrorMessage = "Liczba punktów musi być między 1 a 100")]
    public int LiczbaPunktow { get; set; }

    [Required]
    public int QuizId { get; set; }

    public List<CreateOdpowiedzViewModel> Odpowiedzi { get; set; } = new List<CreateOdpowiedzViewModel>();
  }

  public class CreateOdpowiedzViewModel
  {
    [Required(ErrorMessage = "Treść odpowiedzi jest wymagana")]
    [StringLength(200, ErrorMessage = "Treść odpowiedzi może mieć maximum 200 znaków")]
    public string Tresc { get; set; } = string.Empty;

    public bool CzyPoprawna { get; set; }
  }
}