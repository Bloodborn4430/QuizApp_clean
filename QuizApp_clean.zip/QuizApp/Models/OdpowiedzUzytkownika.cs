using System.ComponentModel.DataAnnotations;

namespace QuizApp.Models
{
  public class OdpowiedzUzytkownika
  {
    public int Id { get; set; }

    [Required]
    public int WynikQuizuId { get; set; }

    [Required]
    public int PytanieId { get; set; }

    [Required]
    public int OdpowiedzId { get; set; }

    public DateTime DataOdpowiedzi { get; set; } = DateTime.Now;

    // Nawigacja do wyniku quizu
    public WynikQuizu WynikQuizu { get; set; } = null!;

    // Nawigacja do pytania
    public Pytanie Pytanie { get; set; } = null!;

    // Nawigacja do odpowiedzi
    public Odpowiedz Odpowiedz { get; set; } = null!;
  }
}