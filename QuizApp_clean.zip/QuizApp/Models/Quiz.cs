using System.ComponentModel.DataAnnotations;

namespace QuizApp.Models
{
  public class Quiz
  {
    public int Id { get; set; }

    [Required(ErrorMessage = "Tytuł jest wymagany")]
    [StringLength(200, ErrorMessage = "Tytuł może mieć maximum 200 znaków")]
    public string Tytul { get; set; } = string.Empty;

    [Required(ErrorMessage = "Opis jest wymagany")]
    [StringLength(1000, ErrorMessage = "Opis może mieć maximum 1000 znaków")]
    public string Opis { get; set; } = string.Empty;

    public DateTime DataUtworzenia { get; set; } = DateTime.Now;

    public string AutorId { get; set; } = string.Empty;

    // Nawigacja do użytkownika
    public ApplicationUser? Autor { get; set; }

    // Nawigacja do pytań
    public ICollection<Pytanie> Pytania { get; set; } = new List<Pytanie>();

    // Nawigacja do wyników
    public ICollection<WynikQuizu> Wyniki { get; set; } = new List<WynikQuizu>();
  }
}