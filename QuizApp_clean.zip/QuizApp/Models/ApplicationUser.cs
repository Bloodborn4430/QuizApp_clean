using Microsoft.AspNetCore.Identity;

namespace QuizApp.Models
{
  public class ApplicationUser : IdentityUser
  {
    public string? FirstName { get; set; }
    public string? LastName { get; set; }

    public DateTime DataRejestracji { get; set; } = DateTime.Now;

    // Nawigacja do utworzonych quizów
    public ICollection<Quiz> UtworzoneQuizy { get; set; } = new List<Quiz>();

    // Nawigacja do wyników quizów
    public ICollection<WynikQuizu> WynikiQuizow { get; set; } = new List<WynikQuizu>();
  }
}