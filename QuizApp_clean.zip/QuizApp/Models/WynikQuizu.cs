using System.ComponentModel.DataAnnotations;

namespace QuizApp.Models
{
  public class WynikQuizu
  {
    public int Id { get; set; }

    public int ZdobytePunkty { get; set; }

    public int MaksymalnePunkty { get; set; }

    public DateTime DataWypelnienia { get; set; } = DateTime.Now;

    [Required]
    public int QuizId { get; set; }

    [Required]
    public string UzytkownikId { get; set; } = string.Empty;

    // Nawigacja do quizu
    public Quiz Quiz { get; set; } = null!;

    // Nawigacja do użytkownika
    public ApplicationUser Uzytkownik { get; set; } = null!;

    // Nawigacja do odpowiedzi użytkownika
    public ICollection<OdpowiedzUzytkownika> OdpowiedziUzytkownika { get; set; } = new List<OdpowiedzUzytkownika>();

    // Właściwość obliczeniowa - procent wyniku
    public double ProcentWyniku => MaksymalnePunkty > 0 ? (double)ZdobytePunkty / MaksymalnePunkty * 100 : 0;
  }
}