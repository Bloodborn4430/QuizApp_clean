using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using QuizApp.Models;

namespace QuizApp.Data
{
  public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
  {
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Quiz> Quizy { get; set; }
    public DbSet<Pytanie> Pytania { get; set; }
    public DbSet<Odpowiedz> Odpowiedzi { get; set; }
    public DbSet<WynikQuizu> WynikiQuizow { get; set; }
    public DbSet<OdpowiedzUzytkownika> OdpowiedziUzytkownikow { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
      base.OnModelCreating(builder);

      // Konfiguracja relacji Quiz -> ApplicationUser
      builder.Entity<Quiz>()
          .HasOne(q => q.Autor)
          .WithMany(u => u.UtworzoneQuizy)
          .HasForeignKey(q => q.AutorId)
          .OnDelete(DeleteBehavior.Cascade);

      // Konfiguracja relacji Pytanie -> Quiz
      builder.Entity<Pytanie>()
          .HasOne(p => p.Quiz)
          .WithMany(q => q.Pytania)
          .HasForeignKey(p => p.QuizId)
          .OnDelete(DeleteBehavior.Cascade);

      // Konfiguracja relacji Odpowiedz -> Pytanie
      builder.Entity<Odpowiedz>()
          .HasOne(o => o.Pytanie)
          .WithMany(p => p.Odpowiedzi)
          .HasForeignKey(o => o.PytanieId)
          .OnDelete(DeleteBehavior.Cascade);

      // Konfiguracja relacji WynikQuizu -> Quiz
      builder.Entity<WynikQuizu>()
          .HasOne(w => w.Quiz)
          .WithMany(q => q.Wyniki)
          .HasForeignKey(w => w.QuizId)
          .OnDelete(DeleteBehavior.Cascade);

      // Konfiguracja relacji WynikQuizu -> ApplicationUser
      builder.Entity<WynikQuizu>()
          .HasOne(w => w.Uzytkownik)
          .WithMany(u => u.WynikiQuizow)
          .HasForeignKey(w => w.UzytkownikId)
          .OnDelete(DeleteBehavior.Cascade);

      // Konfiguracja relacji OdpowiedzUzytkownika -> WynikQuizu
      builder.Entity<OdpowiedzUzytkownika>()
          .HasOne(ou => ou.WynikQuizu)
          .WithMany(w => w.OdpowiedziUzytkownika)
          .HasForeignKey(ou => ou.WynikQuizuId)
          .OnDelete(DeleteBehavior.Cascade);

      // Konfiguracja relacji OdpowiedzUzytkownika -> Pytanie
      builder.Entity<OdpowiedzUzytkownika>()
          .HasOne(ou => ou.Pytanie)
          .WithMany(p => p.OdpowiedziUzytkownikow)
          .HasForeignKey(ou => ou.PytanieId)
          .OnDelete(DeleteBehavior.Restrict);

      // Konfiguracja relacji OdpowiedzUzytkownika -> Odpowiedz
      builder.Entity<OdpowiedzUzytkownika>()
          .HasOne(ou => ou.Odpowiedz)
          .WithMany(o => o.OdpowiedziUzytkownikow)
          .HasForeignKey(ou => ou.OdpowiedzId)
          .OnDelete(DeleteBehavior.Restrict);

      // Indeksy dla lepszej wydajności
      builder.Entity<Quiz>()
          .HasIndex(q => q.AutorId);

      builder.Entity<Pytanie>()
          .HasIndex(p => p.QuizId);

      builder.Entity<Odpowiedz>()
          .HasIndex(o => o.PytanieId);

      builder.Entity<WynikQuizu>()
          .HasIndex(w => new { w.QuizId, w.UzytkownikId });

      builder.Entity<OdpowiedzUzytkownika>()
          .HasIndex(ou => ou.WynikQuizuId);
    }
  }
}