using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using QuizApp.Models;

namespace QuizApp.Data
{
  public static class DatabaseSeeder
  {
    public static async Task SeedAsync(IServiceProvider serviceProvider)
    {
      using var scope = serviceProvider.CreateScope();
      var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
      var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

      // Upewnij się, że baza danych jest utworzona
      await context.Database.EnsureCreatedAsync();

      // Sprawdź, czy dane już istnieją
      if (await context.Quizy.AnyAsync())
      {
        return; // Dane już istnieją
      }

      // Utwórz użytkowników testowych
      var users = await CreateTestUsersAsync(userManager);

      // Utwórz quizy z pytaniami i odpowiedziami
      await CreateQuizesAsync(context, users);

      // Utwórz przykładowe wyniki
      await CreateTestResultsAsync(context, users);

      await context.SaveChangesAsync();
    }

    private static async Task<List<ApplicationUser>> CreateTestUsersAsync(UserManager<ApplicationUser> userManager)
    {
      var users = new List<ApplicationUser>();

      var testUsers = new[]
      {
                new { Email = "jan.kowalski@example.com", UserName = "jan.kowalski", FirstName = "Jan", LastName = "Kowalski" },
                new { Email = "anna.nowak@example.com", UserName = "anna.nowak", FirstName = "Anna", LastName = "Nowak" },
                new { Email = "piotr.wisniewski@example.com", UserName = "piotr.wisniewski", FirstName = "Piotr", LastName = "Wiśniewski" },
                new { Email = "maria.wojcik@example.com", UserName = "maria.wojcik", FirstName = "Maria", LastName = "Wójcik" },
                new { Email = "tomasz.kowalczyk@example.com", UserName = "tomasz.kowalczyk", FirstName = "Tomasz", LastName = "Kowalczyk" }
            };

      foreach (var userData in testUsers)
      {
        var existingUser = await userManager.FindByEmailAsync(userData.Email);
        if (existingUser == null)
        {
          var user = new ApplicationUser
          {
            UserName = userData.UserName,
            Email = userData.Email,
            EmailConfirmed = true,
            FirstName = userData.FirstName,
            LastName = userData.LastName
          };

          var result = await userManager.CreateAsync(user, "Test123!");
          if (result.Succeeded)
          {
            users.Add(user);
          }
        }
        else
        {
          users.Add(existingUser);
        }
      }

      return users;
    }

    private static async Task CreateQuizesAsync(ApplicationDbContext context, List<ApplicationUser> users)
    {
      var quizy = new List<Quiz>
            {
                // Quiz o historii Polski
                new Quiz
                {
                    Tytul = "Historia Polski",
                    Opis = "Quiz sprawdzający wiedzę z historii Polski od średniowiecza po czasy współczesne.",
                    DataUtworzenia = DateTime.Now.AddDays(-30),
                    AutorId = users[0].Id,
                    Pytania = new List<Pytanie>
                    {
                        new Pytanie
                        {
                            Tresc = "W którym roku Mieszko I przyjął chrzest?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "966", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "965", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "967", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "964", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Kto był pierwszym królem Polski?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Bolesław Chrobry", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Mieszko I", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Kazimierz Wielki", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Władysław Łokietek", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "W którym roku odbyła się bitwa pod Grunwaldem?",
                            LiczbaPunktow = 3,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "1410", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "1409", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "1411", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "1412", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Kto był ostatnim królem Polski?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Stanisław August Poniatowski", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Jan III Sobieski", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "August III Sas", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Stanisław Leszczyński", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "W którym roku Polska odzyskała niepodległość?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "1918", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "1917", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "1919", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "1920", CzyPoprawna = false }
                            }
                        }
                    }
                },

                // Quiz o geografii Polski
                new Quiz
                {
                    Tytul = "Geografia Polski",
                    Opis = "Test wiedzy o geografii Polski - góry, rzeki, miasta i regiony.",
                    DataUtworzenia = DateTime.Now.AddDays(-25),
                    AutorId = users[1].Id,
                    Pytania = new List<Pytanie>
                    {
                        new Pytanie
                        {
                            Tresc = "Jaka jest najwyższa góra w Polsce?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Rysy", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Śnieżka", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Kasprowy Wierch", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Giewont", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Która rzeka jest najdłuższą rzeką w Polsce?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Wisła", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Odra", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Warta", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Bug", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Ile województw ma Polska?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "16", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "15", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "17", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "14", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Które miasto jest stolicą województwa śląskiego?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Katowice", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Gliwice", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Sosnowiec", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Zabrze", CzyPoprawna = false }
                            }
                        }
                    }
                },

                // Quiz o literaturze polskiej
                new Quiz
                {
                    Tytul = "Literatura Polska",
                    Opis = "Quiz o polskich pisarzach, poetach i ich najważniejszych dziełach.",
                    DataUtworzenia = DateTime.Now.AddDays(-20),
                    AutorId = users[2].Id,
                    Pytania = new List<Pytanie>
                    {
                        new Pytanie
                        {
                            Tresc = "Kto napisał 'Pan Tadeusz'?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Adam Mickiewicz", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Juliusz Słowacki", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Zygmunt Krasiński", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Cyprian Kamil Norwid", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Która powieść Henryka Sienkiewicza otrzymała Nagrodę Nobla?",
                            LiczbaPunktow = 3,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Całokształt twórczości", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Quo Vadis", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Krzyżacy", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Trylogia", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Kto napisał 'Lalka'?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Bolesław Prus", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Eliza Orzeszkowa", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Maria Konopnicka", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Stefan Żeromski", CzyPoprawna = false }
                            }
                        }
                    }
                },

                // Quiz o sporcie
                new Quiz
                {
                    Tytul = "Sport w Polsce",
                    Opis = "Quiz o polskich sportowcach, dyscyplinach sportowych i osiągnięciach.",
                    DataUtworzenia = DateTime.Now.AddDays(-15),
                    AutorId = users[3].Id,
                    Pytania = new List<Pytanie>
                    {
                        new Pytanie
                        {
                            Tresc = "Kto jest najlepszym polskim piłkarzem wszech czasów?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Robert Lewandowski", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Zbigniew Boniek", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Kazimierz Deyna", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Grzegorz Lato", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "W którym roku Polska wygrała mistrzostwa Europy w piłce nożnej?",
                            LiczbaPunktow = 3,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Nigdy nie wygrała", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "1972", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "1982", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "2016", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Kto jest najsłynniejszą polską tenisistką?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Iga Świątek", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Agnieszka Radwańska", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Urszula Radwańska", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Magdalena Fręch", CzyPoprawna = false }
                            }
                        }
                    }
                },

                // Quiz o nauce i technologii
                new Quiz
                {
                    Tytul = "Nauka i Technologia",
                    Opis = "Quiz o polskich wynalazkach, odkryciach naukowych i nowoczesnych technologiach.",
                    DataUtworzenia = DateTime.Now.AddDays(-10),
                    AutorId = users[4].Id,
                    Pytania = new List<Pytanie>
                    {
                        new Pytanie
                        {
                            Tresc = "Kto odkrył polon i rad?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Maria Skłodowska-Curie", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Mikołaj Kopernik", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Marian Rejewski", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Ignacy Łukasiewicz", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Kto wynalazł lampę naftową?",
                            LiczbaPunktow = 2,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Ignacy Łukasiewicz", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Jan Szczepanik", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Józef Hofmann", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Stefan Banach", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Kto sformułował teorię heliocentryczną?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Mikołaj Kopernik", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Johannes Kepler", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Galileusz", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Tycho Brahe", CzyPoprawna = false }
                            }
                        }
                    }
                },

                // Quiz łatwy dla początkujących
                new Quiz
                {
                    Tytul = "Podstawowa Wiedza Ogólna",
                    Opis = "Prosty quiz z podstawowej wiedzy ogólnej - idealny dla początkujących.",
                    DataUtworzenia = DateTime.Now.AddDays(-5),
                    AutorId = users[0].Id,
                    Pytania = new List<Pytanie>
                    {
                        new Pytanie
                        {
                            Tresc = "Jaka jest stolica Polski?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Warszawa", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Kraków", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Gdańsk", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Wrocław", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Ile ma nóg pająk?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "8", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "6", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "10", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "4", CzyPoprawna = false }
                            }
                        },
                        new Pytanie
                        {
                            Tresc = "Które zwierzę jest największe na świecie?",
                            LiczbaPunktow = 1,
                            Odpowiedzi = new List<Odpowiedz>
                            {
                                new Odpowiedz { Tresc = "Płetwal błękitny", CzyPoprawna = true },
                                new Odpowiedz { Tresc = "Słoń afrykański", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Żyrafa", CzyPoprawna = false },
                                new Odpowiedz { Tresc = "Wieloryb", CzyPoprawna = false }
                            }
                        }
                    }
                }
            };

      await context.Quizy.AddRangeAsync(quizy);
    }

    private static async Task CreateTestResultsAsync(ApplicationDbContext context, List<ApplicationUser> users)
    {
      // Pobierz quizy z bazy danych (po zapisaniu)
      await context.SaveChangesAsync();
      var quizy = await context.Quizy.Include(q => q.Pytania).ThenInclude(p => p.Odpowiedzi).ToListAsync();

      var random = new Random();
      var wyniki = new List<WynikQuizu>();

      // Utwórz losowe wyniki dla każdego użytkownika
      foreach (var user in users)
      {
        // Każdy użytkownik wypełnia losową liczbę quizów (1-4)
        var liczbaQuizow = random.Next(1, 5);
        var wybraneQuizy = quizy.OrderBy(x => random.Next()).Take(liczbaQuizow);

        foreach (var quiz in wybraneQuizy)
        {
          var maksymalnePunkty = quiz.Pytania.Sum(p => p.LiczbaPunktow);

          // Losuj wynik między 30% a 95%
          var procentWyniku = random.Next(30, 96);
          var zdobytePunkty = (int)Math.Round(maksymalnePunkty * procentWyniku / 100.0);

          var wynik = new WynikQuizu
          {
            QuizId = quiz.Id,
            UzytkownikId = user.Id,
            ZdobytePunkty = zdobytePunkty,
            MaksymalnePunkty = maksymalnePunkty,
            DataWypelnienia = DateTime.Now.AddDays(-random.Next(1, 30)),
            OdpowiedziUzytkownika = new List<OdpowiedzUzytkownika>()
          };

          // Utwórz odpowiedzi użytkownika dla każdego pytania
          foreach (var pytanie in quiz.Pytania)
          {
            // 70% szans na poprawną odpowiedź dla wysokich wyników
            var czyPoprawna = procentWyniku > 70 ? random.Next(100) < 80 : random.Next(100) < 50;

            Odpowiedz wybranaOdpowiedz;
            if (czyPoprawna)
            {
              wybranaOdpowiedz = pytanie.Odpowiedzi.First(o => o.CzyPoprawna);
            }
            else
            {
              var niepoprawneOdpowiedzi = pytanie.Odpowiedzi.Where(o => !o.CzyPoprawna).ToList();
              wybranaOdpowiedz = niepoprawneOdpowiedzi[random.Next(niepoprawneOdpowiedzi.Count)];
            }

            wynik.OdpowiedziUzytkownika.Add(new OdpowiedzUzytkownika
            {
              PytanieId = pytanie.Id,
              OdpowiedzId = wybranaOdpowiedz.Id
            });
          }

          wyniki.Add(wynik);
        }
      }

      await context.WynikiQuizow.AddRangeAsync(wyniki);
    }
  }
}