using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models;

namespace QuizApp.Controllers
{
  [Authorize]
  public class StatystykiController : Controller
  {
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public StatystykiController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
      _context = context;
      _userManager = userManager;
    }

    // GET: Statystyki
    public async Task<IActionResult> Index()
    {
      var userId = _userManager.GetUserId(User);

      // Pobieranie quizów użytkownika z podstawowymi statystykami
      var mojeQuizy = await _context.Quizy
          .Where(q => q.AutorId == userId)
          .Include(q => q.Wyniki)
          .Include(q => q.Pytania)
          .OrderByDescending(q => q.DataUtworzenia)
          .ToListAsync();

      // Obliczanie statystyk po stronie klienta
      var statystyki = mojeQuizy.Select(q => new
      {
        Quiz = q,
        LiczbaWypelnien = q.Wyniki.Count,
        SredniWynik = q.Wyniki.Any() ? q.Wyniki.Average(w => w.MaksymalnePunkty > 0 ? (double)w.ZdobytePunkty / w.MaksymalnePunkty * 100 : 0) : 0
      }).ToList();

      return View(statystyki);
    }

    // GET: Statystyki/Szczegoly/5
    public async Task<IActionResult> Szczegoly(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }

      var quiz = await _context.Quizy
          .Include(q => q.Autor)
          .Include(q => q.Pytania)
              .ThenInclude(p => p.Odpowiedzi)
          .Include(q => q.Wyniki)
              .ThenInclude(w => w.Uzytkownik)
          .FirstOrDefaultAsync(q => q.Id == id);

      if (quiz == null)
      {
        return NotFound();
      }

      // Sprawdzenie czy użytkownik jest autorem quizu
      var userId = _userManager.GetUserId(User);
      if (quiz.AutorId != userId)
      {
        return Forbid();
      }

      // Przygotowanie szczegółowych statystyk
      var wyniki = quiz.Wyniki.Select(w => w.MaksymalnePunkty > 0 ? (double)w.ZdobytePunkty / w.MaksymalnePunkty * 100 : 0).ToList();

      var statystyki = new
      {
        Quiz = quiz,
        LiczbaWypelnien = quiz.Wyniki.Count,
        SredniWynik = wyniki.Any() ? wyniki.Average() : 0,
        NajlepszyWynik = wyniki.Any() ? wyniki.Max() : 0,
        NajgorszyWynik = wyniki.Any() ? wyniki.Min() : 0,
        StatystykiPytan = await PobierzStatystykiPytan(id.Value)
      };

      return View(statystyki);
    }

    // GET: Statystyki/WynikiQuizu/5
    public async Task<IActionResult> WynikiQuizu(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }

      var quiz = await _context.Quizy
          .Include(q => q.Autor)
          .FirstOrDefaultAsync(q => q.Id == id);

      if (quiz == null)
      {
        return NotFound();
      }

      // Sprawdzenie czy użytkownik jest autorem quizu
      var userId = _userManager.GetUserId(User);
      if (quiz.AutorId != userId)
      {
        return Forbid();
      }

      var wyniki = await _context.WynikiQuizow
          .Include(w => w.Uzytkownik)
          .Where(w => w.QuizId == id)
          .OrderByDescending(w => w.DataWypelnienia)
          .ToListAsync();

      ViewBag.Quiz = quiz;
      return View(wyniki);
    }

    private async Task<List<object>> PobierzStatystykiPytan(int quizId)
    {
      var pytania = await _context.Pytania
          .Include(p => p.Odpowiedzi)
          .Where(p => p.QuizId == quizId)
          .ToListAsync();

      var statystykiPytan = new List<object>();

      foreach (var pytanie in pytania)
      {
        // Pobieranie wszystkich odpowiedzi użytkowników dla tego pytania
        var odpowiedziUzytkownikow = await _context.OdpowiedziUzytkownikow
            .Include(ou => ou.Odpowiedz)
            .Where(ou => ou.PytanieId == pytanie.Id)
            .ToListAsync();

        var liczbaCalosc = odpowiedziUzytkownikow.Count;

        var statystykiOdpowiedzi = pytanie.Odpowiedzi.Select(odpowiedz => new
        {
          Odpowiedz = odpowiedz,
          LiczbaWyborow = odpowiedziUzytkownikow.Count(ou => ou.OdpowiedzId == odpowiedz.Id),
          ProcentWyborow = liczbaCalosc > 0
                ? (double)odpowiedziUzytkownikow.Count(ou => ou.OdpowiedzId == odpowiedz.Id) / liczbaCalosc * 100
                : 0
        }).ToList();

        statystykiPytan.Add(new
        {
          Pytanie = pytanie,
          LiczbaOdpowiedzi = liczbaCalosc,
          StatystykiOdpowiedzi = statystykiOdpowiedzi
        });
      }

      return statystykiPytan;
    }
  }
}