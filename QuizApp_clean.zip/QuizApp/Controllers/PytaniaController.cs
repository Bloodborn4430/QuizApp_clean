using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models;

namespace QuizApp.Controllers
{
    [Authorize]
    public class PytaniaController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public PytaniaController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Pytania - pokazuje tylko pytania z quizów użytkownika
        public async Task<IActionResult> Index()
        {
            var userId = _userManager.GetUserId(User);
            var pytaniaUzytkownika = _context.Pytania
                .Include(p => p.Quiz)
                .Where(p => p.Quiz!.AutorId == userId);

            return View(await pytaniaUzytkownika.ToListAsync());
        }

        // GET: Pytania/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pytanie = await _context.Pytania
                .Include(p => p.Quiz)
                .Include(p => p.Odpowiedzi)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pytanie == null)
            {
                return NotFound();
            }

            // Sprawdzenie czy użytkownik jest autorem quizu
            var userId = _userManager.GetUserId(User);
            if (pytanie.Quiz?.AutorId != userId)
            {
                return Forbid();
            }

            return View(pytanie);
        }

        // GET: Pytania/Create
        public IActionResult Create(int? quizId)
        {
            var viewModel = new CreatePytanieViewModel();
            var userId = _userManager.GetUserId(User);

            if (quizId.HasValue)
            {
                var quiz = _context.Quizy.FirstOrDefault(q => q.Id == quizId.Value && q.AutorId == userId);
                if (quiz == null)
                {
                    return Forbid(); // Quiz nie należy do użytkownika
                }

                ViewBag.QuizTytul = quiz.Tytul;
                viewModel.QuizId = quizId.Value;
            }
            else
            {
                // Pokazuj tylko quizy użytkownika
                var mojeQuizy = _context.Quizy.Where(q => q.AutorId == userId);
                ViewData["QuizId"] = new SelectList(mojeQuizy, "Id", "Tytul");
            }

            return View(viewModel);
        }

        // POST: Pytania/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CreatePytanieViewModel viewModel)
        {
            // Walidacja - minimum 2 odpowiedzi
            if (viewModel.Odpowiedzi == null || viewModel.Odpowiedzi.Count < 2)
            {
                ModelState.AddModelError("", "Pytanie musi mieć minimum 2 odpowiedzi.");
            }

            // Walidacja - przynajmniej jedna poprawna odpowiedź
            if (viewModel.Odpowiedzi != null && !viewModel.Odpowiedzi.Any(o => o.CzyPoprawna))
            {
                ModelState.AddModelError("", "Przynajmniej jedna odpowiedź musi być oznaczona jako poprawna.");
            }

            if (ModelState.IsValid)
            {
                // Tworzenie pytania
                var pytanie = new Pytanie
                {
                    Tresc = viewModel.Tresc,
                    LiczbaPunktow = viewModel.LiczbaPunktow,
                    QuizId = viewModel.QuizId
                };

                _context.Add(pytanie);
                await _context.SaveChangesAsync();

                // Tworzenie odpowiedzi
                if (viewModel.Odpowiedzi != null)
                {
                    foreach (var odpowiedzViewModel in viewModel.Odpowiedzi)
                    {
                        var odpowiedz = new Odpowiedz
                        {
                            Tresc = odpowiedzViewModel.Tresc,
                            CzyPoprawna = odpowiedzViewModel.CzyPoprawna,
                            PytanieId = pytanie.Id
                        };
                        _context.Add(odpowiedz);
                    }
                }

                await _context.SaveChangesAsync();
                return RedirectToAction("Details", "Quizy", new { id = viewModel.QuizId });
            }

            var quiz = _context.Quizy.Find(viewModel.QuizId);
            if (quiz != null)
            {
                ViewBag.QuizTytul = quiz.Tytul;
            }
            else
            {
                ViewData["QuizId"] = new SelectList(_context.Quizy, "Id", "Tytul", viewModel.QuizId);
            }

            return View(viewModel);
        }

        // GET: Pytania/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pytanie = await _context.Pytania
                .Include(p => p.Quiz)
                .FirstOrDefaultAsync(p => p.Id == id);

            if (pytanie == null)
            {
                return NotFound();
            }

            // Dodaj informację o quizie do ViewBag
            ViewBag.QuizInfo = pytanie.Quiz?.Tytul ?? "Nieznany quiz";

            return View(pytanie);
        }

        // POST: Pytania/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Tresc,LiczbaPunktow,QuizId")] Pytanie pytanie)
        {
            if (id != pytanie.Id)
            {
                return NotFound();
            }

            ModelState.Remove("Quiz");

            if (ModelState.IsValid)
            {
                try
                {
                    var originalPytanie = await _context.Pytania.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
                    if (originalPytanie == null)
                    {
                        return NotFound();
                    }

                    pytanie.QuizId = originalPytanie.QuizId;

                    _context.Update(pytanie);
                    await _context.SaveChangesAsync();

                    return RedirectToAction("Details", new { id = pytanie.Id });
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PytanieExists(pytanie.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            // Jeśli walidacja nie przeszła, ponownie załaduj informacje o quizie
            var quiz = await _context.Quizy.FindAsync(pytanie.QuizId);
            ViewBag.QuizInfo = quiz?.Tytul ?? "Nieznany quiz";

            return View(pytanie);
        }

        // GET: Pytania/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pytanie = await _context.Pytania
                .Include(p => p.Quiz)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (pytanie == null)
            {
                return NotFound();
            }

            return View(pytanie);
        }

        // POST: Pytania/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pytanie = await _context.Pytania.FindAsync(id);
            if (pytanie != null)
            {
                var quizId = pytanie.QuizId;
                _context.Pytania.Remove(pytanie);
                await _context.SaveChangesAsync();

                return RedirectToAction("Details", "Quizy", new { id = quizId });
            }

            return RedirectToAction(nameof(Index));
        }

        private bool PytanieExists(int id)
        {
            return _context.Pytania.Any(e => e.Id == id);
        }
    }
}
