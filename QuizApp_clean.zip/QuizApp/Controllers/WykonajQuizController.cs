using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models;

namespace QuizApp.Controllers
{
  [Authorize]
  public class WykonajQuizController : Controller
  {
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;

    public WykonajQuizController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
    {
      _context = context;
      _userManager = userManager;
    }

    // GET: WykonajQuiz
    public async Task<IActionResult> Index()
    {
      var quizy = await _context.Quizy
          .Include(q => q.Autor)
          .Include(q => q.Pytania)
          .OrderByDescending(q => q.DataUtworzenia)
          .ToListAsync();

      return View(quizy);
    }

    // GET: WykonajQuiz/Start/5
    public async Task<IActionResult> Start(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }

      var quiz = await _context.Quizy
          .Include(q => q.Pytania)
              .ThenInclude(p => p.Odpowiedzi)
          .Include(q => q.Autor)
          .FirstOrDefaultAsync(q => q.Id == id);

      if (quiz == null)
      {
        return NotFound();
      }

      // Sprawdzenie czy użytkownik już wypełnił ten quiz
      var userId = _userManager.GetUserId(User);
      var czyJuzWypelnil = await _context.WynikiQuizow
          .AnyAsync(w => w.QuizId == id && w.UzytkownikId == userId);

      if (czyJuzWypelnil)
      {
        TempData["Error"] = "Już wypełniłeś ten quiz!";
        return RedirectToAction(nameof(Index));
      }

      if (!quiz.Pytania.Any())
      {
        TempData["Error"] = "Ten quiz nie ma jeszcze pytań!";
        return RedirectToAction(nameof(Index));
      }

      return View(quiz);
    }

    // POST: WykonajQuiz/Wyslij
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Wyslij(int quizId, Dictionary<int, int> odpowiedzi)
    {
      var quiz = await _context.Quizy
          .Include(q => q.Pytania)
              .ThenInclude(p => p.Odpowiedzi)
          .FirstOrDefaultAsync(q => q.Id == quizId);

      if (quiz == null)
      {
        return NotFound();
      }

      var userId = _userManager.GetUserId(User);

      // Sprawdzenie czy użytkownik już wypełnił ten quiz
      var czyJuzWypelnil = await _context.WynikiQuizow
          .AnyAsync(w => w.QuizId == quizId && w.UzytkownikId == userId);

      if (czyJuzWypelnil)
      {
        TempData["Error"] = "Już wypełniłeś ten quiz!";
        return RedirectToAction(nameof(Index));
      }

      // Obliczanie wyniku
      int zdobytePunkty = 0;
      int maksymalnePunkty = quiz.Pytania.Sum(p => p.LiczbaPunktow);

      // Tworzenie wyniku quizu
      var wynikQuizu = new WynikQuizu
      {
        QuizId = quizId,
        UzytkownikId = userId!,
        ZdobytePunkty = 0, // Zostanie zaktualizowane poniżej
        MaksymalnePunkty = maksymalnePunkty,
        DataWypelnienia = DateTime.Now
      };

      _context.WynikiQuizow.Add(wynikQuizu);
      await _context.SaveChangesAsync();

      // Zapisywanie odpowiedzi użytkownika i obliczanie punktów
      foreach (var pytanie in quiz.Pytania)
      {
        if (odpowiedzi.ContainsKey(pytanie.Id))
        {
          var odpowiedzId = odpowiedzi[pytanie.Id];
          var odpowiedz = pytanie.Odpowiedzi.FirstOrDefault(o => o.Id == odpowiedzId);

          if (odpowiedz != null)
          {
            var odpowiedzUzytkownika = new OdpowiedzUzytkownika
            {
              WynikQuizuId = wynikQuizu.Id,
              PytanieId = pytanie.Id,
              OdpowiedzId = odpowiedzId,
              DataOdpowiedzi = DateTime.Now
            };

            _context.OdpowiedziUzytkownikow.Add(odpowiedzUzytkownika);

            // Dodanie punktów jeśli odpowiedź poprawna
            if (odpowiedz.CzyPoprawna)
            {
              zdobytePunkty += pytanie.LiczbaPunktow;
            }
          }
        }
      }

      // Aktualizacja wyniku
      wynikQuizu.ZdobytePunkty = zdobytePunkty;
      await _context.SaveChangesAsync();

      return RedirectToAction(nameof(Wynik), new { id = wynikQuizu.Id });
    }

    // GET: WykonajQuiz/Wynik/5
    public async Task<IActionResult> Wynik(int? id)
    {
      if (id == null)
      {
        return NotFound();
      }

      var wynik = await _context.WynikiQuizow
          .Include(w => w.Quiz)
          .Include(w => w.Uzytkownik)
          .Include(w => w.OdpowiedziUzytkownika)
              .ThenInclude(ou => ou.Pytanie)
          .Include(w => w.OdpowiedziUzytkownika)
              .ThenInclude(ou => ou.Odpowiedz)
          .FirstOrDefaultAsync(w => w.Id == id);

      if (wynik == null)
      {
        return NotFound();
      }

      // Sprawdzenie czy użytkownik ma prawo do tego wyniku
      var userId = _userManager.GetUserId(User);
      if (wynik.UzytkownikId != userId)
      {
        return Forbid();
      }

      return View(wynik);
    }

    // GET: WykonajQuiz/MojeWyniki
    public async Task<IActionResult> MojeWyniki()
    {
      var userId = _userManager.GetUserId(User);
      var wyniki = await _context.WynikiQuizow
          .Include(w => w.Quiz)
          .Where(w => w.UzytkownikId == userId)
          .OrderByDescending(w => w.DataWypelnienia)
          .ToListAsync();

      return View(wyniki);
    }
  }
}