using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models;

namespace QuizApp.Controllers
{
    [Authorize]
    public class QuizyController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public QuizyController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Quizy - pokazuje tylko quizy użytkownika
        public async Task<IActionResult> Index()
        {
            var userId = _userManager.GetUserId(User);
            var mojeQuizy = _context.Quizy
                .Include(q => q.Autor)
                .Include(q => q.Pytania)
                .Where(q => q.AutorId == userId);

            return View(await mojeQuizy.ToListAsync());
        }

        // GET: Quizy/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var quiz = await _context.Quizy
                .Include(q => q.Autor)
                .Include(q => q.Pytania)
                    .ThenInclude(p => p.Odpowiedzi)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (quiz == null)
            {
                return NotFound();
            }

            // Sprawdzenie czy użytkownik jest autorem quizu
            var userId = _userManager.GetUserId(User);
            if (quiz.AutorId != userId)
            {
                return Forbid();
            }

            return View(quiz);
        }

        // GET: Quizy/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Quizy/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Quiz quiz)
        {
            ModelState.Remove("AutorId");
            ModelState.Remove("Autor");

            if (ModelState.IsValid)
            {
                // Automatyczne przypisanie aktualnego użytkownika jako autora
                quiz.AutorId = _userManager.GetUserId(User)!;
                quiz.DataUtworzenia = DateTime.Now;

                _context.Add(quiz);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(quiz);
        }

        // GET: Quizy/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var quiz = await _context.Quizy.FindAsync(id);
            if (quiz == null)
            {
                return NotFound();
            }

            // Sprawdzenie czy użytkownik jest autorem quizu
            var userId = _userManager.GetUserId(User);
            if (quiz.AutorId != userId)
            {
                return Forbid();
            }

            return View(quiz);
        }

        // POST: Quizy/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Tytul,Opis,DataUtworzenia,AutorId")] Quiz quiz)
        {
            if (id != quiz.Id)
            {
                return NotFound();
            }

            // Sprawdzenie czy użytkownik jest autorem quizu
            var userId = _userManager.GetUserId(User);
            if (quiz.AutorId != userId)
            {
                return Forbid();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(quiz);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!QuizExists(quiz.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(quiz);
        }

        // GET: Quizy/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var quiz = await _context.Quizy
                .Include(q => q.Autor)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (quiz == null)
            {
                return NotFound();
            }

            // Sprawdzenie czy użytkownik jest autorem quizu
            var userId = _userManager.GetUserId(User);
            if (quiz.AutorId != userId)
            {
                return Forbid();
            }

            return View(quiz);
        }

        // POST: Quizy/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var quiz = await _context.Quizy.FindAsync(id);
            if (quiz != null)
            {
                // Sprawdzenie czy użytkownik jest autorem quizu
                var userId = _userManager.GetUserId(User);
                if (quiz.AutorId != userId)
                {
                    return Forbid();
                }

                _context.Quizy.Remove(quiz);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool QuizExists(int id)
        {
            return _context.Quizy.Any(e => e.Id == id);
        }
    }
}
