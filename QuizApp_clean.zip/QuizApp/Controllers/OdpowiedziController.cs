using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QuizApp.Data;
using QuizApp.Models;

namespace QuizApp.Controllers
{
    [Authorize]
    public class OdpowiedziController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public OdpowiedziController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Odpowiedzi - pokazuje tylko odpowiedzi użytkownika pogrupowane według pytań
        public async Task<IActionResult> Index()
        {
            var userId = _userManager.GetUserId(User);

            var odpowiedziUzytkownika = await _context.Odpowiedzi
                .Include(o => o.Pytanie)
                .ThenInclude(p => p!.Quiz)
                .Where(o => o.Pytanie!.Quiz!.AutorId == userId)
                .OrderBy(o => o.Pytanie!.Quiz!.Tytul)
                .ThenBy(o => o.PytanieId)
                .ThenBy(o => o.CzyPoprawna ? 0 : 1) // Poprawne odpowiedzi na początku
                .ToListAsync();

            // Grupowanie według pytań
            var pogrupowaneOdpowiedzi = odpowiedziUzytkownika
                .GroupBy(o => o.Pytanie)
                .ToList();

            ViewBag.PogrupowaneOdpowiedzi = pogrupowaneOdpowiedzi;

            return View(odpowiedziUzytkownika);
        }

        // GET: Odpowiedzi/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var odpowiedz = await _context.Odpowiedzi
                .Include(o => o.Pytanie)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (odpowiedz == null)
            {
                return NotFound();
            }

            return View(odpowiedz);
        }

        // GET: Odpowiedzi/Create
        public IActionResult Create(int? pytanieId)
        {
            if (pytanieId.HasValue)
            {
                var pytanie = _context.Pytania.Find(pytanieId.Value);
                if (pytanie == null)
                {
                    return NotFound();
                }

                ViewBag.PytanieTresc = pytanie.Tresc;
                ViewBag.PytanieId = pytanieId.Value;
            }
            else
            {
                ViewData["PytanieId"] = new SelectList(_context.Pytania, "Id", "Tresc");
            }

            return View();
        }

        // POST: Odpowiedzi/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Tresc,CzyPoprawna,PytanieId")] Odpowiedz odpowiedz)
        {
            ModelState.Remove("Pytanie");

            if (ModelState.IsValid)
            {
                _context.Add(odpowiedz);
                await _context.SaveChangesAsync();

                var pytanie = await _context.Pytania.FindAsync(odpowiedz.PytanieId);
                if (pytanie != null)
                {
                    return RedirectToAction("Details", "Pytania", new { id = odpowiedz.PytanieId });
                }

                return RedirectToAction(nameof(Index));
            }

            var pytanieForView = _context.Pytania.Find(odpowiedz.PytanieId);
            if (pytanieForView != null)
            {
                ViewBag.PytanieTresc = pytanieForView.Tresc;
                ViewBag.PytanieId = odpowiedz.PytanieId;
            }
            else
            {
                ViewData["PytanieId"] = new SelectList(_context.Pytania, "Id", "Tresc", odpowiedz.PytanieId);
            }

            return View(odpowiedz);
        }

        // GET: Odpowiedzi/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var odpowiedz = await _context.Odpowiedzi
                .Include(o => o.Pytanie)
                .FirstOrDefaultAsync(o => o.Id == id);
            if (odpowiedz == null)
            {
                return NotFound();
            }

            // Przekaż informacje o pytaniu do wyświetlenia (tylko do odczytu)
            ViewBag.PytanieTresc = odpowiedz.Pytanie?.Tresc ?? "Nieznane pytanie";

            return View(odpowiedz);
        }

        // POST: Odpowiedzi/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Tresc,CzyPoprawna,PytanieId")] Odpowiedz odpowiedz)
        {
            if (id != odpowiedz.Id)
            {
                return NotFound();
            }

            // Usuń walidację dla Pytanie
            ModelState.Remove("Pytanie");

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(odpowiedz);
                    await _context.SaveChangesAsync();

                    // Przekieruj do szczegółów pytania zamiast Index
                    return RedirectToAction("Details", "Pytania", new { id = odpowiedz.PytanieId });
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OdpowiedzExists(odpowiedz.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            var pytanie = await _context.Pytania.FindAsync(odpowiedz.PytanieId);
            ViewBag.PytanieTresc = pytanie?.Tresc ?? "Nieznane pytanie";

            return View(odpowiedz);
        }

        // GET: Odpowiedzi/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var odpowiedz = await _context.Odpowiedzi
                .Include(o => o.Pytanie)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (odpowiedz == null)
            {
                return NotFound();
            }

            ViewBag.PytanieId = odpowiedz.PytanieId;

            return View(odpowiedz);
        }

        // POST: Odpowiedzi/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var odpowiedz = await _context.Odpowiedzi.FindAsync(id);
            if (odpowiedz != null)
            {
                var pytanieId = odpowiedz.PytanieId;
                _context.Odpowiedzi.Remove(odpowiedz);
                await _context.SaveChangesAsync();

                return RedirectToAction("Details", "Pytania", new { id = pytanieId });
            }

            return RedirectToAction(nameof(Index));
        }

        private bool OdpowiedzExists(int id)
        {
            return _context.Odpowiedzi.Any(e => e.Id == id);
        }
    }
}
