using Microsoft.EntityFrameworkCore;
using QuizApp.Data;

namespace QuizApp.Commands
{
  /// <summary>
  /// Komenda do inicjalizacji bazy danych z danymi testowymi
  /// Użycie: dotnet run --seed
  /// </summary>
  public static class SeedCommand
  {
    public static async Task<bool> HandleSeedCommand(string[] args, IServiceProvider serviceProvider)
    {
      if (args.Contains("--seed"))
      {
        try
        {
          await DatabaseSeeder.SeedAsync(serviceProvider);
          return true;
        }
        catch (Exception ex)
        {
          return true; // Zwracamy true, żeby zakończyć aplikację
        }
      }

      return false; // Nie było komendy --seed, kontynuuj normalnie
    }
  }
}