# QuizApp - Dokumentacja Techniczna

**Autor:** Maksym Krytskyi

## Opis Projektu

QuizApp to aplikacja webowa umożliwiająca tworzenie, zarządzanie i wypełnianie quizów online. System pozwala użytkownikom na tworzenie własnych quizów z pytaniami wielokrotnego wyboru, udostępnianie ich innym użytkownikom oraz śledzenie wyników i statystyk.

## Specyfikacja Technologii

- **Framework:** ASP.NET Core 8.0
- **Baza danych:** SQLite
- **ORM:** Entity Framework Core 8.0
- **Autentykacja:** ASP.NET Core Identity
- **Frontend:** HTML5, CSS3, Bootstrap 5, JavaScript
- **Architektura:** MVC (Model-View-Controller)

## Instrukcje Pierwszego Uruchomienia

1. **Sklonuj repozytorium:**
   ```bash
   git clone [url-repozytorium]
   cd QuizApp
   ```

2. **Przywróć pakiety NuGet:**
   ```bash
   dotnet restore
   ```

3. **Utwórz bazę danych:**
   ```bash
   dotnet ef database update
   ```

4. **Uruchom aplikację:**
   ```bash
   dotnet run
   ```

5. **Otwórz przeglądarkę i przejdź do:**
   ```
   https://localhost:5001
   ```

## Struktura Projektu

```
QuizApp/
├── Controllers/           # Kontrolery MVC
├── Models/               # Modele danych
├── Views/                # Widoki Razor
│   ├── Shared/          # Współdzielone widoki
│   ├── Home/            # Widoki strony głównej
│   ├── Quizy/           # Widoki zarządzania quizami
│   ├── Pytania/         # Widoki zarządzania pytaniami
│   ├── Odpowiedzi/      # Widoki zarządzania odpowiedziami
│   ├── WykonajQuiz/     # Widoki wypełniania quizów
│   └── Statystyki/      # Widoki statystyk
├── Data/                # Kontekst bazy danych
├── Migrations/          # Migracje Entity Framework
├── wwwroot/            # Pliki statyczne (CSS, JS, obrazy)
└── Program.cs          # Punkt wejścia aplikacji
```

## Modele Danych

### ApplicationUser
**Opis:** Rozszerzony model użytkownika Identity
**Pola:**
- `FirstName` (string, wymagane, max 50 znaków) - Imię użytkownika
- `LastName` (string, wymagane, max 50 znaków) - Nazwisko użytkownika
- `Quizy` (ICollection<Quiz>) - Kolekcja quizów utworzonych przez użytkownika
- `WynikiQuizow` (ICollection<WynikQuizu>) - Kolekcja wyników quizów użytkownika

### Quiz
**Opis:** Reprezentuje quiz utworzony przez użytkownika
**Pola:**
- `Id` (int, klucz główny) - Unikalny identyfikator
- `Tytul` (string, wymagane, max 200 znaków) - Tytuł quizu
- `Opis` (string, wymagane, max 1000 znaków) - Opis quizu
- `DataUtworzenia` (DateTime) - Data utworzenia quizu
- `AutorId` (string, wymagane) - ID autora quizu
- `Autor` (ApplicationUser) - Autor quizu
- `Pytania` (ICollection<Pytanie>) - Kolekcja pytań w quizie
- `WynikiQuizow` (ICollection<WynikQuizu>) - Kolekcja wyników tego quizu

### Pytanie
**Opis:** Reprezentuje pytanie w quizie
**Pola:**
- `Id` (int, klucz główny) - Unikalny identyfikator
- `Tresc` (string, wymagane, max 500 znaków) - Treść pytania
- `LiczbaPunktow` (int, wymagane, min 1, max 100) - Liczba punktów za pytanie
- `QuizId` (int, wymagane) - ID quizu do którego należy pytanie
- `Quiz` (Quiz) - Quiz do którego należy pytanie
- `Odpowiedzi` (ICollection<Odpowiedz>) - Kolekcja odpowiedzi do pytania
- `OdpowiedziUzytkownikow` (ICollection<OdpowiedzUzytkownika>) - Odpowiedzi użytkowników

### Odpowiedz
**Opis:** Reprezentuje możliwą odpowiedź na pytanie
**Pola:**
- `Id` (int, klucz główny) - Unikalny identyfikator
- `Tresc` (string, wymagane, max 300 znaków) - Treść odpowiedzi
- `CzyPoprawna` (bool) - Czy odpowiedź jest poprawna
- `PytanieId` (int, wymagane) - ID pytania do którego należy odpowiedź
- `Pytanie` (Pytanie) - Pytanie do którego należy odpowiedź
- `OdpowiedziUzytkownikow` (ICollection<OdpowiedzUzytkownika>) - Wybory użytkowników

### WynikQuizu
**Opis:** Reprezentuje wynik wypełnionego quizu przez użytkownika
**Pola:**
- `Id` (int, klucz główny) - Unikalny identyfikator
- `UzytkownikId` (string, wymagane) - ID użytkownika
- `Uzytkownik` (ApplicationUser) - Użytkownik który wypełnił quiz
- `QuizId` (int, wymagane) - ID wypełnionego quizu
- `Quiz` (Quiz) - Wypełniony quiz
- `ZdobytePunkty` (int) - Liczba zdobytych punktów
- `MaksymalnePunkty` (int) - Maksymalna możliwa liczba punktów
- `ProcentWyniku` (double) - Wynik w procentach
- `DataWypelnienia` (DateTime) - Data wypełnienia quizu
- `OdpowiedziUzytkownika` (ICollection<OdpowiedzUzytkownika>) - Odpowiedzi użytkownika

### OdpowiedzUzytkownika
**Opis:** Reprezentuje odpowiedź udzieloną przez użytkownika na konkretne pytanie
**Pola:**
- `Id` (int, klucz główny) - Unikalny identyfikator
- `WynikQuizuId` (int, wymagane) - ID wyniku quizu
- `WynikQuizu` (WynikQuizu) - Wynik quizu
- `PytanieId` (int, wymagane) - ID pytania
- `Pytanie` (Pytanie) - Pytanie
- `OdpowiedzId` (int, wymagane) - ID wybranej odpowiedzi
- `Odpowiedz` (Odpowiedz) - Wybrana odpowiedź

### CreatePytanieViewModel
**Opis:** Model widoku do tworzenia pytania z odpowiedziami
**Pola:**
- `Tresc` (string, wymagane) - Treść pytania
- `LiczbaPunktow` (int, wymagane) - Liczba punktów
- `QuizId` (int, wymagane) - ID quizu
- `Odpowiedzi` (List<CreateOdpowiedzViewModel>) - Lista odpowiedzi

### CreateOdpowiedzViewModel
**Opis:** Model widoku do tworzenia odpowiedzi
**Pola:**
- `Tresc` (string, wymagane) - Treść odpowiedzi
- `CzyPoprawna` (bool) - Czy odpowiedź jest poprawna

## Kontrolery i Metody

### HomeController
- **Index()** [GET] - Wyświetla stronę główną
- **Privacy()** [GET] - Wyświetla stronę polityki prywatności

### QuizyController
- **Index()** [GET] - Wyświetla listę quizów użytkownika
- **Details(int id)** [GET] - Wyświetla szczegóły quizu z pytaniami i odpowiedziami
- **Create()** [GET] - Wyświetla formularz tworzenia nowego quizu
- **Create(Quiz quiz)** [POST] - Tworzy nowy quiz, waliduje dane
- **Edit(int id)** [GET] - Wyświetla formularz edycji quizu
- **Edit(int id, Quiz quiz)** [POST] - Aktualizuje quiz, sprawdza autoryzację
- **Delete(int id)** [GET] - Wyświetla potwierdzenie usunięcia quizu
- **DeleteConfirmed(int id)** [POST] - Usuwa quiz wraz z powiązanymi danymi

### PytaniaController
- **Index()** [GET] - Wyświetla pytania z quizów użytkownika
- **Details(int id)** [GET] - Wyświetla szczegóły pytania z odpowiedziami
- **Create(int? quizId)** [GET] - Wyświetla formularz tworzenia pytania
- **Create(CreatePytanieViewModel model)** [POST] - Tworzy pytanie z odpowiedziami
- **Edit(int id)** [GET] - Wyświetla formularz edycji pytania
- **Edit(int id, Pytanie pytanie)** [POST] - Aktualizuje pytanie
- **Delete(int id)** [GET] - Wyświetla potwierdzenie usunięcia pytania
- **DeleteConfirmed(int id)** [POST] - Usuwa pytanie z odpowiedziami

### OdpowiedziController
- **Index()** [GET] - Wyświetla odpowiedzi pogrupowane według pytań użytkownika
- **Details(int id)** [GET] - Wyświetla szczegóły odpowiedzi
- **Create(int? pytanieId)** [GET] - Wyświetla formularz tworzenia odpowiedzi
- **Create(Odpowiedz odpowiedz)** [POST] - Tworzy nową odpowiedź
- **Edit(int id)** [GET] - Wyświetla formularz edycji odpowiedzi (pytanie niezmienne)
- **Edit(int id, Odpowiedz odpowiedz)** [POST] - Aktualizuje odpowiedź
- **Delete(int id)** [GET] - Wyświetla potwierdzenie usunięcia odpowiedzi
- **DeleteConfirmed(int id)** [POST] - Usuwa odpowiedź

### WykonajQuizController
- **Index()** [GET] - Wyświetla listę dostępnych quizów do wypełnienia
- **Start(int id)** [GET] - Rozpoczyna quiz, wyświetla pierwsze pytanie
- **Pytanie(int quizId, int numerPytania, int? odpowiedzId)** [POST] - Przetwarza odpowiedź i przechodzi do następnego pytania
- **Wynik(int id)** [GET] - Wyświetla wynik wypełnionego quizu
- **MojeWyniki()** [GET] - Wyświetla historię wyników użytkownika

### StatystykiController
- **Index()** [GET] - Wyświetla statystyki wszystkich quizów użytkownika
- **Szczegoly(int id)** [GET] - Wyświetla szczegółowe statystyki konkretnego quizu
- **WynikiQuizu(int id)** [GET] - Wyświetla wszystkie wyniki konkretnego quizu

## System Użytkowników

### Role w Systemie
System nie implementuje ról - wszyscy zarejestrowani użytkownicy mają równe uprawnienia.

### Możliwości Użytkowników

**Goście (niezalogowani):**
- Przeglądanie strony głównej
- Rejestracja i logowanie
- Brak dostępu do funkcjonalności quizów

**Zalogowani użytkownicy:**
- Tworzenie własnych quizów
- Zarządzanie swoimi quizami (edycja, usuwanie)
- Tworzenie pytań i odpowiedzi do swoich quizów
- Wypełnianie quizów innych użytkowników
- Przeglądanie swoich wyników
- Dostęp do statystyk swoich quizów
- Przeglądanie odpowiedzi pogrupowanych według pytań

### Powiązania z Użytkownikiem

**Dane powiązane z konkretnym użytkownikiem:**
- Utworzone quizy (tylko autor może je edytować/usuwać)
- Pytania i odpowiedzi (poprzez powiązanie z quizem)
- Wyniki wypełnionych quizów
- Statystyki własnych quizów

**Dane globalne:**
- Lista wszystkich quizów dostępnych do wypełnienia
- Możliwość wypełniania quizów innych użytkowników

## Najciekawsze Funkcjonalności

### 1. Dynamiczne Tworzenie Pytań z Odpowiedziami
System umożliwia tworzenie pytań z dowolną liczbą odpowiedzi w jednym formularzu. Wykorzystuje JavaScript do dynamicznego dodawania/usuwania pól odpowiedzi z walidacją po stronie klienta i serwera.

### 2. Inteligentny System Wypełniania Quizów
- Sesyjne przechowywanie postępu quizu
- Automatyczne przechodzenie między pytaniami
- Zabezpieczenie przed powrotem do poprzednich pytań
- Obliczanie wyniku w czasie rzeczywistym

### 3. Zaawansowane Statystyki
- Statystyki na poziomie quizu (średni wynik, liczba wypełnień)
- Analiza odpowiedzi - które odpowiedzi były najczęściej wybierane
- Wizualizacja danych za pomocą progress-barów i kolorowych kart
- Grupowanie danych według różnych kryteriów

### 4. System Autoryzacji na Poziomie Danych
- Użytkownicy widzą tylko swoje quizy w panelu zarządzania
- Automatyczna filtracja danych według właściciela
- Zabezpieczenie przed nieautoryzowanym dostępem do cudzych danych
- Sprawdzanie uprawnień na poziomie kontrolera

### 5. Responsywny Interfejs z Dynamicznymi Elementami
- Adaptacyjny design działający na wszystkich urządzeniach
- Kolorowe wskaźniki postępu i wyników
- Interaktywne elementy (hover effects, animacje)
- Intuicyjna nawigacja z breadcrumbs

### 6. Zaawansowana Walidacja
- Walidacja po stronie klienta i serwera
- Sprawdzanie unikalności tytułów quizów
- Walidacja struktury quizu (minimum pytań, odpowiedzi)
- Zabezpieczenie przed pustymi lub nieprawidłowymi danymi

### 7. System Powiadomień i Feedbacku
- Komunikaty sukcesu/błędu po akcjach
- Potwierdzenia przed usunięciem danych
- Informacyjne alerty o stanie systemu
- Wizualne wskaźniki statusu (badges, ikony) 